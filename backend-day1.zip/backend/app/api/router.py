"""
VERIFAI — Main API Router
============================

This file assembles all route modules into one router.

WHY A CENTRAL ROUTER:
- main.py includes ONE router, not ten separate ones
- Easy to see all endpoints at a glance
- When teammates add new modules, they add ONE LINE here

HOW TO ADD A NEW MODULE:
1. Create a new file in app/api/ (e.g., app/api/documents.py)
2. Define a router in that file: router = APIRouter()
3. Add one line here: api_router.include_router(...)
4. That's it — the endpoints are live

CURRENT ROUTES:
- /health → System health check
- /cases  → Case CRUD + officer decision

PLANNED ROUTES (teammates will add these):
- /cases/{id}/documents        → Document upload/management
- /documents/{id}/ocr          → OCR processing
- /documents/{id}/mrz          → MRZ parsing
- /documents/{id}/validation   → Document validation
- /documents/{id}/forensics    → Forensic analysis
- /cases/{id}/face-verification → Face comparison
- /cases/{id}/consistency      → Cross-document checks
- /cases/{id}/risk-assessment  → Risk engine
- /auth                        → Login/register
"""

from fastapi import APIRouter

from app.api.health import router as health_router
from app.api.cases import router as cases_router

api_router = APIRouter()

# Health check — always first, simplest endpoint
api_router.include_router(
    health_router,
    prefix="/health",
    tags=["health"],
)

# Case management — the core workflow
api_router.include_router(
    cases_router,
    prefix="/cases",
    tags=["cases"],
)

# ── Future module routers will be added here ──────────────────────
# Example (uncomment when ready):
#
# from app.api.documents import router as documents_router
# api_router.include_router(
#     documents_router,
#     prefix="/documents",
#     tags=["documents"],
# )
#
# from app.api.auth import router as auth_router
# api_router.include_router(
#     auth_router,
#     prefix="/auth",
#     tags=["auth"],
# )

