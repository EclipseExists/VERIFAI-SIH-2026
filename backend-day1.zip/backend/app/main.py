"""
VERIFAI — FastAPI Application Entry Point
===========================================

This is the file that starts everything.

WHAT THIS FILE DOES:
1. Creates the FastAPI application object
2. Configures CORS (so the React frontend can talk to the API)
3. Sets up the database on startup (creates tables if they don't exist)
4. Mounts all API routes under /api/v1
5. Provides a root welcome endpoint

WHAT IS A LIFESPAN?
- FastAPI's lifespan is code that runs when the server starts and stops
- We use startup to create database tables
- This is fine for development — in production, you'd use Alembic migrations

WHAT IS CORS?
- Cross-Origin Resource Sharing
- Without CORS, a React app on localhost:3000 cannot call a FastAPI app
  on localhost:8000 — the browser blocks it as a security measure
- We allow all origins in development (allow_origins=["*"])
- In production, you'd restrict this to your actual frontend domain
"""

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import get_settings
from app.api.router import api_router
from app.db.session import engine

# ── Import all models so SQLAlchemy knows about them ──────────────
# These imports look unused, but they register each model class with
# Base.metadata. Without these, create_all() won't create the tables.
from app.models.base import Base
from app.models.user import User        # noqa: F401
from app.models.case import Case, Document  # noqa: F401
from app.models.audit import AuditLog   # noqa: F401

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Runs on server startup and shutdown.

    STARTUP:
    - Creates all database tables that don't exist yet
    - This is equivalent to running CREATE TABLE IF NOT EXISTS for each model
    - Safe to run multiple times — it won't drop/recreate existing tables

    WHY NOT ALEMBIC FOR MVP:
    - Alembic is the proper way to manage DB schema changes in production
    - But for a 5-7 day hackathon, auto-create-all is simpler and sufficient
    - We'll add Alembic later if we need schema migrations

    SHUTDOWN:
    - Disposes the database engine (closes all connections cleanly)
    """
    # ── Startup ───────────────────────────────────────────────────
    print(f"🚀 Starting {settings.PROJECT_NAME} v{settings.VERSION}")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    print("✅ Database tables created/verified")

    yield  # The application runs here

    # ── Shutdown ──────────────────────────────────────────────────
    print(f"👋 Shutting down {settings.PROJECT_NAME}")
    await engine.dispose()


# ── Create the FastAPI application ────────────────────────────────
app = FastAPI(
    title=f"{settings.PROJECT_NAME} API",
    description=(
        "AI-Powered Fake Identity & Document Risk Screening — "
        "Decision Support for Checkpoint Officers. "
        "This system provides risk signals and recommendations. "
        "All final decisions are made by human officers."
    ),
    version=settings.VERSION,
    lifespan=lifespan,
)

# ── CORS Middleware ───────────────────────────────────────────────
# TODO: In production, replace ["*"] with actual frontend domain
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],           # Allow React dev server
    allow_credentials=True,
    allow_methods=["*"],           # Allow all HTTP methods
    allow_headers=["*"],           # Allow all headers
)

# ── Mount all API routes under /api/v1 ────────────────────────────
app.include_router(api_router, prefix=settings.API_V1_PREFIX)


@app.get("/", summary="Root", tags=["root"])
async def root():
    """
    Welcome endpoint. Confirms the API is running and points to docs.

    Visit /docs for the interactive Swagger UI where you can test
    every endpoint without writing any frontend code.
    """
    return {
        "message": f"Welcome to {settings.PROJECT_NAME} API",
        "version": settings.VERSION,
        "docs": "/docs",
        "health": f"{settings.API_V1_PREFIX}/health/",
        "description": (
            "VERIFAI is an AI-powered document risk screening system. "
            "It provides risk signals to support officer decisions. "
            "All final decisions are made by human officers."
        ),
    }

